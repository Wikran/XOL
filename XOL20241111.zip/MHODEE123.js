window.onload = function () {
    setTimeout(function () {
        location.reload();
    }, 2400000); // refresh every 40 minutes 40*60*1000
}

$(document).ready(function () {
    var aDXTheme = localStorage["aDXTheme"]
    DevExpress.ui.themes.current(aDXTheme);
});

window.jsPDF = window.jspdf.jsPDF;
applyPlugin(window.jsPDF);
console.clear();

var aaXToX = localStorage["aaXXoX"];
const aaDeptList = [
    { DeptCode: "1186", ENGNAME: "Affinity & SMEs" },
    { DeptCode: "1127", ENGNAME: "Administration" },
    { DeptCode: "1197", ENGNAME: "Claims" },
    { DeptCode: "1192", ENGNAME: "Corporate Risk Services" },
    { DeptCode: "1180", ENGNAME: "Finance & Accounting" },
    { DeptCode: "1196", ENGNAME: "Global Professional and Financial Risks" },
    { DeptCode: "1129", ENGNAME: "Human Resources" }, //1170	Engineering
    { DeptCode: "1170", ENGNAME: "Risk Engineering" },
    { DeptCode: "1182", ENGNAME: "Information Technology" },
    { DeptCode: "1199", ENGNAME: "Legal & Compliance" },
    { DeptCode: "1194", ENGNAME: "Major Accounts" },
    { DeptCode: "1191", ENGNAME: "Multi-National Clients" },
    { DeptCode: "1183", ENGNAME: "Management Support" },
    { DeptCode: "1128", ENGNAME: "People Solutions" },
    { DeptCode: "1190", ENGNAME: "Reinsurance" },
];
console.log(aaDeptList)

const aaTypeOfExp = [
    { TypeCode: "100", TypeName: "Other" },
    { TypeCode: "200", TypeName: "Fleet Card" },
    { TypeCode: "300", TypeName: "Medical" },
    { TypeCode: "400", TypeName: "Travel&Entertainment" },
];

var aaPXIXD = localStorage["aPXIXD"];
var aaEnt = aaPXIXD.includes("X");
var aaUsrN = localStorage["aaXXuX"];

//var aaDMZSn = "https://cbsdev2.locktonwattana.com";
var aaPFDMI = isLocalHost();
var aaXToX = localStorage["aaXXoX"];

var asFullName = localStorage["asFTNAME"];
var asStaffID = localStorage["asSTFID"];
var asDepartment = localStorage["asDEPT"];
console.log(asDepartment)
var aqrFull = "Department LIKE '%" + asDepartment + "%'" //"PayToCode = '" + asStaffID + "'" // scopes based permission (View Only Login Name)  ExpensesCode LIKE aaOnInitAccCode

var afqrFull = "pageID='" + aaPXIXD + "' "
var afURL = aaPFDMI + '/DMQ/XOL/' + atob(aaXToX) + '/' + "326459ff-7ea6-4465-a946-9326b783d492" + '/all' //+ aaPXXI
var afsettings = {
    "url": afURL,
    "method": "POST",
    "timeout": 0,
    "headers": { "Content-Type": "application/json" },
    "data": JSON.stringify({ "@": afqrFull }), //"�pageID='Resigned'�"
};
var jqxhr = $.post(afsettings, function (e) { })
    .done(function (e) {
        //console.log("set aaTBKey");
        aObjMPage = e;
        var aaKeyField = aObjMPage[0].PrimaryKey;
        var aaTBKey = aObjMPage[0].TBKey;

        //$(function () { TOP PRG
        $(() => {

            var aNowDte = new Date()
            // Date Filter 
            var aYearNum = aNowDte.getFullYear()  // 2022
            var aMonthNum = aNowDte.getMonth() // 10
            var aYearStr = aYearNum.toString() // 2022
            var aYearNumS = aNowDte.getFullYear()
            var aYearNumL = aNowDte.getFullYear()
            var aYearStrS = "";
            var aYearStrL = "";
            //---- Year for Medical 5/2021 - 4/2022 
            if (aMonthNum === 0 || aMonthNum === 1 || aMonthNum === 2 || aMonthNum === 3) {
                aYearNumS = aYearNum - 1;
                aYearStrS = aYearNumS.toString(); // 21
            } else {
                aYearStrS = aYearNum.toString(); // 22**
            }
            if (aMonthNum === 0 || aMonthNum === 1 || aMonthNum === 2 || aMonthNum === 3) {
                aYearNumL = aYearNum;
                aYearStrL = aYearNumL.toString(); // 22
            } else {
                aYearNumL = aYearNum + 1;
                aYearStrL = aYearNumL.toString(); // 23**
            }
            var aFilterT = aYearStrS + '/05/01'  //2022/05/01
            var aFilterT2 = aYearStrL + '/04/30'  //2023/04/01       
            console.log("aFilterT = ",aFilterT, "aFilterT2 =",aFilterT2)

            var aMMaMx = localStorage["MMaMx"];
            var aRRgRs = aMMaMx.split('0');
            var aDDeDx = aRRgRs[0];
            var aRrgSx = aRRgRs[1];
            if (jQuery.type(aRrgSx) === "undefined") {
                aRrgSx = "377B";
            }
            let nDataPos = 1;
            let nExcelPos = 2;
            let nPDFPos = 3;
            let nRPTPos = 4;
            var arDataC = aRolesAction(aRrgSx, nDataPos, 1);
            var arDataU = aRolesAction(aRrgSx, nDataPos, 2);
            if (arDataU === 1) {
                var aUpdateText = "Update";
                var aSaveVisible = 1;
                var aCancelText = "Cancel";
                var aCancelicon = "close";
                var aCancelType = "danger";
            } else {
                var aUpdateText = "xxx";
                var aSaveVisible = 0;
                var aCancelText = "EXIT";
                var aCancelicon = "fas fa-sign-out-alt";
                var aCancelType = "success";
            }
            var arDataD = aRolesAction(aRrgSx, nDataPos, 3);
            var arExcelEx = aRolesAction(aRrgSx, nExcelPos, 2);
            var arPDFEx = aRolesAction(aRrgSx, nPDFPos, 2);
            var aNowDatev = new Date()
            var aurl = aaPFDMI + '/DMQ/XOL/' + atob(aaXToX) + '/' + aaTBKey + '/all'
            var aSettings = { "url": aurl, "method": "POST", "timeout": 0, "headers": { "Content-Type": "application/json" }, "data": JSON.stringify({ "@": aqrFull }), };

            $("#gridContainer").dxDataGrid({

                dataSource: new DevExpress.data.CustomStore({
                    key: "REFNO",
                    loadMode: "omit",
                    //load: function () { return $.post(aSettings).done(result => console.log(result)); },
                    load: function () {
                        return fetch(aurl, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ "@": aqrFull }), //
                        })
                            .then(response => {
                                if (!response.ok) {
                                    throw new Error('Network response was not ok');
                                }
                                return response.json();
                            })
                            .then(data => {
                                console.log(data);
                                // Process the data and populate the datagrid here
                                return data;
                            })
                    },

                    insert: function (values) {
                        if (aaEnt) {
                            var ObjKeyData = { EntryBy: aaUsrN, EntryDate: new Date(), PayToCode: asStaffID, PayToName: asFullName, Department: asDepartment };
                            var ObjRowData = JSON.stringify($.extend({}, ObjKeyData, values));
                        }
                        else {
                            var ObjRowData = JSON.stringify(values);
                        }
                        sendRequestNew("Insert", ObjRowData, aaTBKey, aaPFDMI, atob(aaXToX));
                    },
                    update: function (key, values) {
                        var ObjKeyData = { "REFNO": $.trim(key) };   //[aaKeyField] key.trim
                        var ObjRowData = JSON.stringify($.extend({}, ObjKeyData, values));
                        sendRequestNew(aUpdateText, ObjRowData, aaTBKey, aaPFDMI, atob(aaXToX));
                    },
                    remove: function (key) {
                        var ObjKeyData = { "REFNO": $.trim(key) };   //[aaKeyField] key.trim
                        var ObjRowData = JSON.stringify($.extend({}, ObjKeyData));
                        sendRequestNew("Delete", ObjRowData, aaTBKey, aaPFDMI, atob(aaXToX));
                    }
                }),

                allowColumnReordering: true,
                allowColumnResizing: true,
                columnMinWidth: 10,
                columnChooser: {
                    enabled: true
                },
                showBorders: true,
                sorting: {
                    mode: "multiple"
                },
                selection: {
                    mode: 'single',//'multiple'
                },
                groupPanel: {
                    visible: true
                },
                filterRow: {
                    visible: true,
                    applyFilter: "auto"
                },
                headerFilter: {
                    visible: true,
                    allowSearch: true,
                },
                filterPanel: {
                    visible: true
                },
                filterBuilderPopup: {
                    position: {
                        of: window, at: 'top', my: 'top', offset: { y: 5 },
                    },
                    height: 500,
                    width: 1000,
                },
                filterValue: [['ReqDate', '>=', aFilterT], "and", ['ReqDate', '<=', aFilterT2]],  //     [Req.Date] Is any of('2022')                     
                grouping: {
                    autoExpandAll: true,
                },
                searchPanel: {
                    visible: true
                },
                paging: {
                    pageSize: 10
                },
                pager: {
                    showPageSizeSelector: true,
                    allowedPageSizes: [10, 20, 50, 80],
                    showNavigationButtons: true,
                    showInfo: true
                },
                showBorders: true,
                groupPaging: true,
                showColumnLines: true,
                showRowLines: true,
                rowAlternationEnabled: false, //true,
                focusedRowEnabled: false,

                // Export to Excel 		
                export: {
                    enabled: arExcelEx,
                    allowExportSelectedData: true
                },
                onExporting: function (e) {
                    const workbook = new ExcelJS.Workbook();
                    const worksheet = workbook.addWorksheet('DATA');
                    DevExpress.excelExporter.exportDataGrid({
                        worksheet: worksheet,
                        component: e.component
                    }).then(function () {
                        workbook.xlsx.writeBuffer().then(function (buffer) {
                            saveAs(new Blob([buffer], { type: 'application/octet-stream' }), 'EXPREIM' + '.xlsx');
                        });
                    });
                    e.cancel = true;
                },
                //onEditingStart: function(e){
                //    grid.option("editing.popup.title", "Editing");
                //},
                onInitNewRow: function (e) {
                    //e.component.__addingStart = true; 
                    //gridContainer.option("editing.popup.title", "Adding Expenses Reimbursement");
                    let aaID = 1
                    let axRunRun = aGetDateRef();
                    let axLineNo = $.trim(axRunRun) + "-" + String(aaID).padStart(3, '0')
                    e.data.ID = aaID
                    e.data.HeadRefNo = axRunRun
                    e.data.REFNO = axLineNo
                    e.data.PayToCode = asStaffID
                    e.data.PayToName = asFullName
                    e.data.Department = asDepartment
                    e.data.ReqDate = new Date()
                },
                onEditorPreparing: function (e) {
                    if (e.parentType === "dataRow" && arDataU === 0) {
                        e.editorOptions.disabled = true;
                    } else {
                        if (e.parentType === "dataRow" && (e.dataField === "EntryBy" || e.dataField === "EntryDate" || e.dataField === "ReqDate" || e.dataField === "HeadRefNo" || e.dataField === "ID" || e.dataField === "PayToCode" || e.dataField === "PayToName" || e.dataField === "Department")) {
                            e.editorOptions.disabled = true;
                        }
                    }
                },
                onCellPrepared: function (e) {
                    if (e.rowType === "data") {
                        e.cellElement.css("vertical-align", "top");
                    }
                },                
                //
                //
                // Editing
                editing: {
                    mode: "popup", //"row",
                    useIcons: true,
                    allowUpdating: false,
                    allowDeleting: false, //arDataD,
                    allowAdding: false, //arDataC,

                    popup: {
                        title: "Expenses Reimbursement Info",
                        fullScreen: false,
                        showTitle: true,
                        width: 1200,
                        height: 650,
                        position: {
                            my: "top",
                            at: "top",
                            of: "window"
                        },
                        onContentReady: function (e) {
                            e.component.option('toolbarItems[0].visible', aSaveVisible);
                            e.component.option('toolbarItems[0].options.icon', 'save');
                            e.component.option('toolbarItems[0].options.type', 'success');
                            e.component.option('toolbarItems[1].options.text', aCancelText);
                            e.component.option('toolbarItems[1].options.icon', aCancelicon);
                            e.component.option('toolbarItems[1].options.type', aCancelType);
                        }
                    },

                },
                // column list
                columns: [
                    {
                        type: "buttons",
                        width: 80,
                        visible: false, //{ visible: function (e) { return ( e.row.data.Note === "BF") } },
                        buttons: ["edit"],

                    },
                    {
                        dataField: "Division",
                        caption: "Division",
                        sortOrder: "asc",
                        groupIndex: 0,
                        editorType: "dxTextBox",
                        width: 80,
                        visible: true,
                    },
                    {
                        dataField: "HeadRefNo",
                        caption: "REF NO",
                        sortOrder: "asc",
                        groupIndex: 1,
                        editorOptions: { width: 130 },
                        width: 130,
                    },
                    {
                        dataField: "ID",
                        sortOrder: "asc",
                        caption: "NO",
                        //format: "###0",
                        editorOptions: { width: 70 },
                        width: 70
                    },
                    {
                        dataField: "ReqDate",
                        caption: "Submitted Date",
                        dataType: "date",
                        format: "dd/MM/yyyy",
                        editorOptions: { width: 120 },
                        validationRules: [{ type: "required" }],
                        width: 120,
                        visible: true,
                    },
                    {
                        dataField: "ERODate01",
                        caption: "Treatment Date",
                        dataType: "date",
                        format: "dd/MM/yyyy",
                        width: 150,
                        editorOptions: { width: 150 },
                        visible: false,
                    },
                    {
                        dataField: "PayToCode",
                        caption: "EMPID",
                        editorOptions: { width: 90 },
                        width: 90,
                        visible: false,
                    },
                    {
                        dataField: "PayToName",
                        caption: "Pay To",
                        editorOptions: { width: 200 },
                        width: 200,
                        //visible: false,
                    },
                    {
                        dataField: "Department",
                        caption: "Department",
                        dataType: "string",
                        editorOptions: { width: 90 },
                        Lookup: {
                            dataSource: aaDeptList, //Deptcode, EngName
                            valueExpr: "DeptCode",
                            displayExpr: "ENGNAME",
                        },
                        width: 90,
                        visible: false,
                    },
                    {
                        dataField: "ENGNAME",
                        caption: "Department Name.",
                        dataType: "string",
                        calculateCellValue: function (data) {
                            return aaDeptList.find((dept) => dept.DeptCode === data.Department)?.ENGNAME;
                        },
                        width: 180,
                        visible: true,
                    },
                    {
                        dataField: "ExpGroupDescEng",//"ExpensesDescription",
                        caption: "Expenses",
                        dataType: "string",
                        editorType: "dxTextArea",
                        editorOptions: { width: 150 },
                        width: 150,
                        visible: true,
                    },
                    {
                        dataField: "ERODesc03",
                        caption: "Hospital/Clinic Name",
                        dataType: "string",
                        width: 140,
                        visible: false,
                    },
                    {
                        dataField: "EROCode02",
                        caption: "Patient",
                        dataType: "string",
                        editorOptions: { width: 110 },
                        width: 110,
                        visible: false,
                    },
                    {
                        dataField: "ERORefNo3",//"ExpensesDescription",
                        caption: "Sub Expenses",
                        editorType: "dxTextArea",
                        editorOptions: { width: 200 },
                        width: 200,
                        visible: false,
                    },
                    {
                        dataField: "ERODesc02",
                        caption: "Disease", //dropDownDisease
                        dataType: "string",
                        editorOptions: { width: 200 }, //, height: 80
                        width: 200,
                        visible: false,
                    },
                    {
                        dataField: "LocalAmount",
                        caption: "Actual Amount",
                        dataType: "number",
                        format: { type: "fixedPoint", precision: 2 },
                        editorOptions: { format: "#,##0.00", width: 120 },
                        width: 120,
                        visible: false,
                    },
                    {
                        dataField: "RefundedAmount", //ERORefNo3
                        caption: "Reimbursement",
                        dataType: "number",
                        format: { type: "fixedPoint", precision: 2 },
                        editorOptions: { format: "#,##0.00", width: 150 },
                        width: 150,
                    },
                    {
                        dataField: "ERStatus",
                        caption: "Status",
                        editorType: "dxTextBox",
                        editorOptions: { width: 180 },
                        width: 180,
                        //visible: false,
                    },
                    {
                        dataField: "ERODesc05",
                        caption: "HR NOTE",
                        dataType: "string",
                        cssClass: "colorRED",
                        editorOptions: { width: 250, height: 80, readOnly: true }, //, height: 80
                        width: 250,
                        visible: false,
                    },
                    {
                        dataField: "PBatchNo",
                        caption: "Pay Batch No",
                        dataType: "string",
                        width: 120,
                        visible: false,
                    },
                    {
                        dataField: "PBatchDate",
                        caption: "Batch Date",
                        dataType: "date",
                        format: "dd/MM/yyyy",
                        width: 120,
                        visible: false,
                    },
                    {
                        dataField: "PSPvDate",
                        caption: "EST Payment Date",
                        dataType: "date",
                        format: "dd/MM/yyyy",
                        width: 120,
                        editorOptions: { width: 120 },
                        visible: false,
                    },
                    {
                        dataField: "ExpensesCode",
                        caption: "Expenses Code",
                        dataType: "string",
                        editorOptions: { width: 120 },
                        width: 120,
                        visible: false,
                    },

                    {
                        dataField: "EntryBy",
                        caption: "Entry By",
                        value: [aaUsrN],
                        editorOptions: { width: 150 },
                        visible: false,
                    },
                    {
                        dataField: "EntryDate",
                        caption: "Entry Date",
                        value: [aNowDatev],
                        dataType: "date",
                        format: "dd/MM/yyyy",
                        editorOptions: { width: 150 },
                        visible: false,
                    },
                    {
                        type: "buttons",
                        width: 80,
                        buttons: [
                            {
                                hint: "Add a item",
                                icon: "add",
                                visible: false,
                                onClick: function (e) {

                                    let aBlankDate = "1900-01-01T00:00:00" //new Date('1900-01-01T00:00')
                                    //console.log(aBlankDate)
                                    let axRunRun = e.row.data.HeadRefNo
                                    let aaTT = aGetD2V(aaPFDMI, "[WIKRAN-W10].ExtraOnLine.dbo.ERnextIDview Where HeadRefNo LIKE '" + axRunRun + "%'", "NextID", "aaOBJnn")
                                    let aNextNOa = JSON.parse(localStorage.getItem("aaOBJnn"));
                                    let aaID = aNextNOa[0].NextID
                                    let axLineNo = $.trim(axRunRun) + "-" + String(aaID).padStart(3, '0')
                                    //let aObjKeyData = { ID: aaID, HeadRefNo: axRunRun, REFNO: axLineNo, EROAmount: 0, PBatchDate: aBlankDate,PSPvDate: aBlankDate,ERODate01: aBlankDate,ERODate02: aBlankDate,ERODate03: aBlankDate,ERODate04: aBlankDate,ERODate05: aBlankDate,ERODate06: aBlankDate} //{EntryBy: aaUsrN , EntryDate: new Date(), PayToCode: asStaffID, PayToName: asFullName, Department: asDepartment };
                                    let aObjKeyData = { REFNO: axLineNo, ID: aaID, LocalAmount: 0, Amount: 0, Note: "", ERORefNo1: "" }
                                    let aObjRowData = JSON.stringify($.extend({}, e.row.data, aObjKeyData)); //values
                                    //var clonedItem = $.extend({}, e.row.data, { REFNO: axRunRun }); //++maxID
                                    //alert(aObjRowData)
                                    sendRequestNew("Insert", aObjRowData, aaTBKey, aaPFDMI, atob(aaXToX));
                                    //employees.splice(e.row.rowIndex, 0, clonedItem);
                                    e.component.refresh(true);
                                    e.component.refresh(true);
                                    e.component.refresh(true);
                                    e.event.preventDefault();
                                }
                            },

                            {
                                hint: "Extra Edit",
                                icon: "print", //"fas fa-marker",
                                visible: false,
                                //visible: function(e) {
                                //    //return !e.row.isEditing;
                                //    return (e.row.data.ID === 1) //false;
                                //},
                                onClick: function (e) {
                                    aPopUpForm(e.row.data, 1);
                                    e.component.refresh(true);
                                    e.component.refresh(true);
                                    e.component.refresh(true);
                                    e.component.refresh(true);
                                    e.event.preventDefault();
                                    dataGrid.refresh();
                                }

                            },

                        ]
                    },
                ],
                // summary
                summary: {
                    recalculateWhileEditing: true,
                    skipEmptyValues: false,
                    totalItems: [
                        {
                            column: "REFNO",
                            summaryType: "count",
                            //          summaryType: "max",
                            //          valueFormat: "currency",
                            //          showInGroupFooter: false,
                            //          alignByColumn: true            
                            displayFormat: "{0} Items",
                        },
                        {
                            column: "LocalAmount",
                            summaryType: "sum",
                            //          summaryType: "max",
                            valueFormat: "#,##0.00",
                            //          showInGroupFooter: false,
                            //          alignByColumn: true            
                            displayFormat: "{0}",
                        },
                        {
                            column: "RefundedAmount",
                            summaryType: "sum",
                            valueFormat: "#,##0.00",
                            //showInGroupFooter: true,
                            //alignByColumn: true,           
                            displayFormat: "{0}",
                        },
                    ],
                    groupItems: [
                        {
                            column: "ExpensesCode",
                            summaryType: "count",
                            displayFormat: "{0} Items",
                        },
                        {
                            column: "LocalAmount",
                            summaryType: "sum",
                            valueFormat: "#,##0.00",
                            showInGroupFooter: true,
                            alignByColumn: true,
                            displayFormat: "{0}",
                        },
                        {
                            column: "RefundedAmount",
                            summaryType: "sum",
                            valueFormat: "#,##0.00",
                            showInGroupFooter: true,
                            alignByColumn: true,
                            displayFormat: "{0}",
                        },
                    ],
                },
                // Tool Bar
                onToolbarPreparing: function (e) {
                    var dataGrid = e.component;
                    e.toolbarOptions.items.unshift(
                        {
                            location: "after",
                            widget: "dxButton",
                            type: "success",
                            options: {
                                icon: "fas fa-table",
                                text: 'Pivot',
                                type: "default",
                                stylingMode: "contained", //"outlined",
                                width: 140,
                                onClick: function (e) {
                                    aPivotPopUp(); //e.data
                                }
                            }
                        },
                        {
                            location: "after",
                            widget: "dxButton",
                            type: "success",
                            options: {
                                icon: 'collapse',
                                text: 'Collapse All',
                                width: 140,
                                onClick: function (e) {
                                    var expanding = e.component.option("text") === "Expand All";
                                    dataGrid.option("grouping.autoExpandAll", expanding);
                                    e.component.option("text", expanding ? "Collapse All" : "Expand All");
                                    e.component.option("icon", expanding ? "collapse" : "expand");
                                }
                            }
                        },
                        {
                            location: "after",
                            widget: "dxButton",
                            visible: arPDFEx,
                            options: {
                                icon: "pdffile",
                                text: "Export to PDF",
                                onClick: function () {
                                    const doc = new jsPDF();
                                    //doc.addFont("font/ANGSA.ttf", "angsana", "normal");
                                    doc.addFont("font/Prompt-ExtraLight.ttf", "Prompt", "normal");
                                    doc.setFont("Prompt", "normal");
                                    DevExpress.pdfExporter.exportDataGrid({
                                        jsPDFDocument: doc,
                                        component: dataGrid,
                                        customizeCell: function (options) {
                                            const { gridCell, pdfCell } = options;
                                            pdfCell.styles = {
                                                font: 'Prompt',
                                                fontSize: 12
                                            }
                                            //}
                                        }
                                    }).then(function () {
                                        doc.save('EXPREIM' + '.pdf');
                                    });
                                }
                            }
                        },
                        {
                            location: "after",
                            widget: "dxButton",
                            options: {
                                icon: "refresh",
                                onClick: function () {
                                    dataGrid.refresh();
                                }
                            }
                        }
                    );
                }

            }).dxDataGrid("instance");

            function aDataGridRF() {
                dataGrid.refresh();
            }

            function aSearchjson(aObjArr, asID) {
                return aObjArr.filter( //aaEmployee
                    function (data) {
                        return data.ACCCODE == asID
                    }
                );
            }

            function aSearchXjson(aObjArr, asID) {
                return aObjArr.filter( //aaEmployee
                    function (data) {
                        return data.Code == asID
                    }
                );
            }

            // benefit popup (x)
            function aPopUpBenefits(iData, aaEmpIDx) { //aaMedical,aaFamily,aaSSO,aaMaternity,aaFleet
                var aYearNum1 = aGetBusYear(1, 4) //aNowDte.getFullYear()
                var aYearStr1 = aYearNum1.toString()
                var aCalYear = aNowDte.getFullYear();
                var aCalYearStr = aCalYear.toString();
                //PayToCode = '101301' and ((ExpGroupDescEng Like '%SSO%' and (QYear = '2022' or QYear = '2023')) or QYear = '2022') AND (TAmount + TRefundAmt) <> 0
                //var aaSqlS = "PayToCode LIKE '" + $.trim(aaEmpIDx) + "%' and QYear = " + aYearStr1 + " AND (TAmount + TRefundAmt) <> 0 "
                var aaSqlS = "PayToCode LIKE '" + $.trim(aaEmpIDx) + "%' AND ((ExpGroupDescEng Like '%SSO%' and (QYear = " + aYearStr1 + " or QYear = " + aCalYearStr + ")) or QYear = " + aYearStr1 + ") AND (TAmount + TRefundAmt) <> 0 "

                //var aaSqlS = "PayToCode LIKE '" + $.trim(aaEmpID) + "%' AND ((ExpGroupDescEng Like '%SSO%' and (QYear = " + aYearStr1 + " or QYear = " + aCalYearStr + ")) or QYear = " + aYearStr1 + ") AND (TAmount + TRefundAmt) <> 0 "                    
                var aaqrFull = aaSqlS;
                var aaurl = aaPFDMI + '/DMQ/XOL/' + atob(aaXToX) + '/' + "D8CAE826-9DFA-4446-A12C-0C42B1A95ADB" + '/all'
                var aaSettings = { "url": aaurl, "method": "POST", "timeout": 0, "headers": { "Content-Type": "application/json" }, "data": JSON.stringify({ "@": aaqrFull }), };


                var aaDataRR = iData
                //$(function () { TOP PRG
                $(() => {
                    const popup = $("#popupBenefitsView").dxPopup({
                        title: "Benefits",
                        width: '900px',
                        height: '600px',
                        position: { offset: "0 -165" }, //{offset: "0 -180"},
                        //shadingColor: "rgb(186, 242, 252)", //rgba(0, 0, 0, 0.2)
                        //position: {offset: "40 -200"}, //{my:"top", at:"top", of:window},
                        //onShowing: function (e) {
                        //    e.component.content().css("background-color", "rgb(242, 253, 255)");
                        //},
                        visible: true,
                        fullScreen: false,
                        showCloseButton: false,
                        showTitle: true,
                        dragEnabled: true,
                        closeOnOutsideClick: false,
                        resizeEnabled: true,
                        //shadingColor:"rgb(190,190,190,0.9)",
                        //toolbarItems: [{toolbar:"top", html: "<span id='popupexit'></span>"}],
                        //toolbarItems: [
                        //    {toolbar:"top", html:"<div padding-top: -7px;><center><img src='./images/locktonlogo70mmblack.png' width='88'></center></div>"}],            
                        contentTemplate: function () {
                            return $("<div />").append(
                                $("<p><div id='Benefits-View' background-color: grey></div></p>"), //'<hr>'
                                $("<p><hr></p>"),
                                $("<span style='font-size: 13px; font-weight: bold; color: darkblue; background-color: rgb(64, 224, 208); border-radius: 3px; border: 0px; padding: 1px 10px;' />") //text-align: center; color:blue; border-radius: 5px; border: 2px solid #73AD21; width: 250px; height: 10px;
                                    .text("MEDICAL BENEFITS BALANCE"),
                                $("<br>"),
                                $("<span style='font-size: 9px;  color: darkblue;' />").text("[NOT SHOW = Never used, Medical = OPD+Dental]"),
                                $("<p><center><div id='Benefits-Movement'></div></center></p>"),
                            );
                        },
                        onContentReady: function () {
                            // $("#Add-dxDataGrid").hide(); // hide dataGrid
                        },
                        toolbarItems: [
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                //html: "<div padding-top: -7px;><img src='./images/locktonlogo70mmblack.png' width='85'></div>" // Logo
                            },
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                widget: "dxButton",
                                //toolbar: "bottom",
                                location: "after",
                                options: {
                                    //text: "EXIT",
                                    icon: "fas fa-times",
                                    stylingMode: "outlined",
                                    type: "danger",
                                    onClick: function (e) {
                                        popup.hide()
                                    }
                                }
                            }]

                    }).dxPopup("instance");

                    const aform = $("#Benefits-View").dxForm({
                        formData: iData, //aXXData[0], //iData, aaLimited
                        showColonAfterLabel: false,
                        labelLocation: "left", //"top",
                        cssClass: "aMarkRef",
                        readOnly: true,
                        colCount: 1,
                        items: [{
                            itemType: "group",
                            //caption: "Refference",
                            //cssClass: "second-group",
                            //AllowFamily,AllowSSO,FleetLimit,MedicalLimit,MaternityLimit,LimitPerCase
                            //IDNO,EmpID,EmpName,EmpDept,EmpPosition,ExpGroupCode,ExpGroupDesc,ExpCode,ExpDesc,RefNo01,RefNo02,RefNo03,RefNo04,RefDesc,LimitedPerTime,MonthlyLimited,TotalLimited,ApproverID,ApproverName,ApproverEmail,HRApproverID,HRApproverName,HRApproverEmail,FAApproverID,FAApproverName,FAApproverEmail,Note,AllowFamily,AllowSSO,FleetLimit,MedicalLimit,MaternityLimit,LimitPerCase
                            colCount: 3,
                            items: [
                                {
                                    dataField: "EmpName",
                                    label: { text: "Name" },
                                    dataType: "string",
                                    editorType: "dxTextBox",
                                    editorOptions: { value: aaDataRR[0].EmpName, width: 150 }, //value: asFullName,
                                },
                                {
                                    dataField: "AllowFamily",
                                    label: { text: "Allow Family" },
                                    dataType: "boolean",
                                    //editorType: "dxTextBox",
                                    editorOptions: { value: aaDataRR[0].AllowFamily, width: 100 }, //value: aaFamily,
                                },

                                {
                                    dataField: "AllowSSO",
                                    label: { text: "Allow SSO" },
                                    dataType: "boolean",
                                    //editorType: "dxTextBox",
                                    editorOptions: { value: aaDataRR[0].AllowSSO, width: 100 }, //value: aaSSO,
                                },
                                {
                                    dataField: "MedicalLimit",
                                    label: { text: "Medical Limit" },
                                    dataType: "number",
                                    //disabled: true,
                                    editorOptions: { value: aaDataRR[0].MedicalLimit, format: "#,##0.00", rtlEnabled: true, width: 150, readOnly: true }, //value: aaLMontyly,
                                    visible: true, //value: aaMedical,
                                },
                                {
                                    dataField: "LimitPerCase",
                                    dtatype: "integer",
                                    label: { text: "Medical Limit per time" },
                                    editorOptions: { value: aaDataRR[0].LimitPerCase, format: "#,##0.00", rtlEnabled: true, width: 150, readOnly: true }, //value: aaLMontyly,
                                    visible: (aaDataRR[0].LimitPerCase !== 0),
                                },
                                {
                                    dataField: "MaternityLimit",
                                    label: { text: "Maternity Limit" },
                                    dataType: "number",
                                    //disabled: true,
                                    editorOptions: { value: aaDataRR[0].MaternityLimit, format: "#,##0.00", rtlEnabled: true, width: 150, readOnly: true }, //value: aaLMontyly,
                                    visible: (aaDataRR[0].MaternityLimit !== 0), //value: aaMaternity,
                                },
                                {
                                    itemType: "empty"
                                },
                                {
                                    dataField: "FleetLimit",
                                    label: { text: "Fleet Card Limit" },
                                    dataType: "number",
                                    //disabled: true,
                                    editorOptions: { value: aaDataRR[0].FleetLimit, format: "#,##0.00", rtlEnabled: true, width: 150, readOnly: true }, //value: aaLMontyly,
                                    visible: (aaDataRR[0].FleetLimit !== 0),
                                },
                                {
                                    dataField: "RefNo01",
                                    label: { text: "Plate No" },
                                    editorType: "dxTextBox",
                                    editorOptions: { value: aaDataRR[0].RefNo01, width: 150 },
                                    visible: (aaDataRR[0].FleetLimit !== 0),
                                },
                                {
                                    dataField: "RefNo02",
                                    label: { text: "Fleet Card NO" },
                                    editorType: "dxTextBox",
                                    editorOptions: { value: aaDataRR[0].RefNo02, width: 150 },
                                    visible: (aaDataRR[0].FleetLimit !== 0),
                                },
                            ]

                        },

                        ]

                    }).dxForm("instance");

                    //Benefits Popup
                    $("#Benefits-Movement").dxDataGrid({

                        dataSource: new DevExpress.data.CustomStore({
                            key: "PayToCode",
                            loadMode: "omit",
                            /*
                            load: function () {
                                return $.post(aaPFDMI + '/DMQ/XOL/' + atob(aaXToX) + '/' + "D8CAE826-9DFA-4446-A12C-0C42B1A95ADB" + '/all', { "@": aaSqlS }) // Change aaTBKey to TokenKey for this table 5102300001
                                    .fail(function () { throw "Data loading error" });
                            },
                            */
                            load: function () { return $.post(aaSettings).done(); },
                        }),

                        ///dataSource: aaiData,
                        allowColumnReordering: true,
                        allowColumnResizing: false,
                        columnMinWidth: 20,
                        columnChooser: {
                            enabled: false //false // true
                        },
                        //PayToCode,PayToName,ExpGroupCode,ExpGroupDescEng,QYear,TAmount,TRefundAmt,LAmount,MRemained
                        showBorders: true,
                        showColumnLines: true,
                        columns: [
                            {
                                dataField: "ExpGroupDescEng",
                                caption: "Expenese",
                                sortOrder: "desc",
                                editorOptions: { width: 120 },
                                width: 120
                            },
                            {
                                dataField: "QYear",
                                caption: "Year",
                                editorOptions: { width: 80 },
                                width: 80,
                                visible: true,
                            },
                            {  //LAmount,MRemained
                                dataField: "LAmount",
                                caption: "Limit Amount",
                                dataType: "number",
                                format: { type: "fixedPoint", precision: 2 },
                                width: 120,
                                visible: true,
                            },
                            {
                                dataField: "TAmount",
                                caption: "Usage",
                                dataType: "number",
                                format: { type: "fixedPoint", precision: 2 },
                                width: 120,
                                visible: true,
                            },
                            {
                                dataField: "TRefundAmt",
                                caption: "Reimbursement",
                                dataType: "number",
                                format: { type: "fixedPoint", precision: 2 },
                                width: 120,
                                visible: true,
                            },

                            {
                                dataField: "MRemained",
                                caption: "Remained",
                                dataType: "number",
                                format: { type: "fixedPoint", precision: 2 },
                                width: 120,
                                visible: true,
                            },
                            /*{
                                dataField: "CR",
                                caption: "CR",
                                editorOptions: { width: 70 },
                                width: 70
                            },
                            {
                                dataField: "CRCODE",
                                caption: "CODE",
                                editorOptions: { width: 100 },
                                width: 100,
                                visible: true,
                            },                          
                            {
                                dataField: "CRName",
                                caption: "Account Name",
                                editorType: "dxTextBox",
                                width: 200,
                                visible: true,
                            },   
 */

                        ],
                        // summary
                        summary: {
                            recalculateWhileEditing: true,
                            skipEmptyValues: false,
                            totalItems: [
                                {
                                    column: "ExpGroupDescEng",
                                    summaryType: "count",
                                    displayFormat: "TOTAL",
                                },
                                {
                                    column: "TAmount",
                                    cssClass: "colorGreen",
                                    summaryType: "sum",
                                    valueFormat: "#,##0.00",
                                    displayFormat: "{0}",
                                },
                                {
                                    column: "TRefundAmt",
                                    cssClass: "colorGreen",
                                    summaryType: "sum",
                                    valueFormat: "#,##0.00",
                                    displayFormat: "{0}",
                                },
                            ],

                        },

                    }).dxDataGrid("instance");

                });
            }

            function aPopUpForm(iData, aWithOTP) {
                if (aWithOTP === undefined) {
                    var aWOTP = 0;
                } else {
                    var aWOTP = 1;
                }
                //alert(iData.HeadRefNo )
                var apwds = "";
                var ausrs = "";
                var aOTP = "";
                var aaPFDMI = isLocalHost();
                //var aOTPm = generateOTP();
                var aii = 0;
                var astr = localStorage["aDXTheme"]
                if (astr.includes("dark")) {
                    var alImg = "<div padding-top: -7px;><center><img src='./images/locktonlogo70mmwhite.png' width='88'></center></div>"
                } else {
                    var alImg = "<div padding-top: -7px;><center><img src='./images/locktonlogo70mmblack.png' width='88'></center></div>"
                }
                // define the $ as jQuery for multiple uses
                jQuery(function ($) {
                    // ...
                    var gbxRateV = 1;
                    const popup = $("#popupContainer").dxPopup({
                        title: "Expenses Reimbursement",
                        width: '1300px',
                        position: { offset: "0 -140" }, //{offset: "0 -180"},
                        //position: {offset: "40 -200"}, //{my:"top", at:"top", of:window},
                        visible: true,
                        fullScreen: true,
                        showCloseButton: false,
                        showTitle: true,
                        dragEnabled: true,
                        closeOnOutsideClick: false,
                        resizeEnabled: true,
                        //shadingColor:"rgb(190,190,190,0.9)",
                        //toolbarItems: [{toolbar:"top", html: "<span id='popupexit'></span>"}],
                        //toolbarItems: [
                        //    {toolbar:"top", html:"<div padding-top: -7px;><center><img src='./images/locktonlogo70mmblack.png' width='88'></center></div>"}],            
                        contentTemplate: function () {
                            return $("<div />").append(
                                $("<p><div id='form'></div></p>"),
                                $("<p><span id='asave'></span></p>"),
                                // $("<p><div id='visibleform'></div></p>"),
                                //$("<p><center><div id='username'></div></center></p>"),
                                // $("<p><center><div id='password'></div></center></p>"),
                                // $("<p><center><div id='OTP'></div></center></p>"),
                                // $("<p <div id='popover1'>Please get OTP from your register e-Mail, put here and then press [LOGIN]</div></p>"),
                                // $("<p><span id='print'></span></p>"), 
                                // $("<span id='popupexit'></span>")                              
                            );
                        },
                        toolbarItems: [
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                html: "<div padding-top: -7px;><img src='./images/locktonlogo70mmblack.png' width='85'></div>"
                            },
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                widget: "dxButton",
                                //toolbar: "bottom",
                                location: "right",
                                options: {
                                    icon: "print",
                                    //text: "Print",
                                    onClick: function () {
                                        window.print()
                                    }
                                }
                            }, {
                                toolbar: "top",
                                locateInMenu: 'always',
                                widget: "dxButton",
                                //toolbar: "bottom",
                                location: "after",
                                options: {
                                    //text: "EXIT",
                                    icon: "fas fa-times",
                                    //type: "danger",                
                                    onClick: function (e) {
                                        popup.hide();
                                    }
                                }
                            }]

                        /* onContentReady: function() { 
                                 $("#OTP").hide(); 
                         }*/
                    }).dxPopup("instance");

                    $("#visibleform").dxCheckBox({
                        text: "Visible Form",
                        value: true,
                        onValueChanged: function (data) {
                            //visible:true,
                            form.option("visible", data.value);
                        }
                    });

                    $("#popupexit").dxButton({
                        icon: "fas fa-times",
                        type: "danger",
                        //text: "EXIT",
                        //width: "120px",
                        visible: true,
                        onClick: function () {
                            popup.hide();
                        }
                    });

                    $("#print").dxButton({
                        icon: "print",
                        //text: "Print",
                        onClick: function () {
                            window.print();
                        }
                    });

                    $("#asave").dxButton({
                        icon: "save",
                        text: "SAVE",
                        type: "success",
                        onClick: function (e) {
                            //window.print();
                            //let aUpdateText = "Update"
                            //var ObjKeyData = {"REFNO": $.trim(key)};   //[aaKeyField] key.trim
                            //var ObjRowData = JSON.stringify($.extend({}, ObjKeyData, values));
                            //sendRequestNew(aUpdateText,ObjRowData,aaTBKey,aaPFDMI,atob(aaXToX));            
                            //alert (iData.REFNO)
                            //alert (iData.LocalAmount)
                            //alert (jQuery.type(iData.LocalAmount))
                            let ObjRowD = JSON.stringify(iData)
                            sendRequestNew("Update", ObjRowD, aaTBKey, aaPFDMI, atob(aaXToX));
                            //e.component.refresh(true);
                            //e.component.refresh(true);
                            //e.component.refresh(true);
                            //e.event.preventDefault();
                            popup.hide();

                        }
                    });


                    const aform = $("#form").dxForm({
                        formData: iData,
                        showColonAfterLabel: false,
                        labelLocation: "top",
                        colCount: 1,
                        items: [{
                            itemType: "group",
                            //caption: "Refference",
                            colCount: 4,
                            items: [{
                                dataField: "HeadRefNo",
                                label: { text: "REF NO" },
                                disabled: true,
                                editorOptions: { width: 150 },
                            },
                            {
                                dataField: "ReqDate",
                                label: { text: "Date" },
                                disabled: true,
                                editorType: "dxDateBox",
                                editorOptions: { displayFormat: "dd/MM/yyyy", width: 150 },	  //showClearButton: true,                  
                            },
                            {
                                dataField: "PayToName",
                                label: { text: "Pay To" },
                                disabled: true,
                                editorOptions: { width: 250 },
                            },
                            //{
                            //    itemType: "empty"
                            //},                           
                            {
                                dataField: "ExpensesDescription",
                                label: { text: "Expenses" },
                                disabled: true,
                                editorOptions: { width: 250 },
                            },


                            ]

                        },
                        {
                            itemType: "group",
                            //caption: "Amount",
                            colCount: 4,
                            items: [{
                                dataField: "Currency",
                                //label: {text: "Currency"},
                                value: "THB",
                                width: 80,
                                validationRules: [{ type: "required" }],
                                /*lookup: {
                                            dataSource: aaCurrency, //Code,Name
                                            valueExpr: "Code",
                                            displayExpr: "Code",
                                        },                            
                                editCellTemplate: dropDownBoxCURR,*/

                                editorType: "dxDropDownBox",
                                editorOptions: {
                                    dataSource: aaCurrency, //Code,Name
                                    valueExpr: "Code",
                                    displayExpr: "Code",
                                    width: 380,
                                    contentTemplate: function (e) {
                                        return $("<div>").dxDataGrid({
                                            dataSource: aaCurrency,
                                            //remoteOperations: true,
                                            columns: [{ dataField: "Code", caption: "Code", width: 80 }, { dataField: "Name", caption: "Currency", width: 150 }, { dataField: "xRate", caption: "X-Rate", width: 80, format: "#,##0.000000" }], //ACCCODE,EDESC,ALTERACC,MAPPING,TDESC,NOTE
                                            hoverStateEnabled: true,
                                            paging: { enabled: true, pageSize: 15 },
                                            searchPanel: { visible: true },
                                            headerFilter: { visible: true },
                                            filterRow: { visible: true },
                                            showBorders: true,
                                            scrolling: { mode: "virtual" },
                                            selection: { mode: "single" },
                                            height: 250,
                                            //selectedRowKeys: [cellInfo.value],                                      
                                            //focusedRowKey: cellInfo.value,
                                            onSelectionChanged: function (sArgs) {
                                                //alert(gbxRateV)
                                                console.log(sArgs.selectedRowKeys[0].xRate)
                                                gbxRateV = sArgs.selectedRowKeys[0].xRate
                                                //alert(gbxRateV)
                                                e.component.option("value", sArgs.selectedRowKeys[0].Code);
                                                //cellInfo.setValue(sArgs.selectedRowKeys[0].Code);
                                                //console.log("v")
                                                //console.log(cellInfo.value)
                                                if (sArgs.selectedRowKeys.length > 0) {
                                                    e.component.close();
                                                }

                                            }
                                        });
                                    },
                                },

                                onFieldDataChanged: function (e) {
                                    var updatedField = e.dataField;
                                    var newValue = e.value;
                                    alert(updatedField)
                                    alert(newValue)
                                    // Event handling commands go here
                                },
                                setCellValue: function (newData, value, currentRowData) {

                                    if (arDataU === 1) {
                                        newData.Currency = value;
                                        let aResult = aSearchXjson(aaCurrency, value);
                                        newData.Xrate = aResult[0].xRate;
                                        //newData.LocalAmount = currentRowData.Amount * (1/aResult[0].xRate);
                                    }
                                },

                            },
                            //{
                            //itemType: "empty"
                            //},                             
                            {
                                dataField: "Xrate",
                                label: { text: "X-Rate" },
                                dataType: "number",
                                //format:{ type:"fixedPoint", precision: 6 },
                                editorType: "dxNumberBox",
                                editorOptions: {
                                    value: gbxRateV,
                                    format: "#,##0.000000",
                                    width: 150,
                                },
                                onValueChanged: function (data) {
                                    console.log(data.value);
                                }
                                //value: gbxRateV,
                                //visible: false,
                            },
                            //{
                            //    itemType: "empty"                               
                            //},
                            {
                                itemType: "tabbed",
                                width: 350,
                                tabPanelOptions: {
                                    deferRendering: false
                                },
                                tabs: [{
                                    title: "HOD Approval",
                                    items: ["Confirmed"]
                                },
                                {
                                    title: "HR Approval",
                                    items: [
                                        {
                                            dataField: "HRApproved",
                                            label: { text: "HR Approved" },
                                            allowEditing: false,
                                        },
                                    ]
                                },
                                {
                                    title: "FA Approval",
                                    items: [
                                        {
                                            dataField: "Approved",
                                            label: { text: "FA Approved" },
                                        },
                                        {
                                            dataField: "PBatchNo",
                                            label: { text: "Pay Batch NO" },
                                            editorOptions: { width: 150 },
                                        },
                                        {
                                            dataField: "PBatchDate",
                                            label: { text: "Data" },
                                            disabled: true,
                                            editorType: "dxDateBox",
                                            editorOptions: { displayFormat: "dd/MM/yyyy", width: 150 },
                                        }
                                    ]
                                }
                                ]
                            }

                            ]
                        },
                        {
                            itemType: "group",
                            caption: "Details",
                            colCount: 7,
                            items: [
                                {
                                    dataField: "ID",
                                    sortOrder: "asc",
                                    label: { text: "NO" },
                                    editorOptions: { format: "###0", rtlEnabled: true, width: 40 },
                                },
                                {
                                    dataField: "ERORefNo1",
                                    label: { text: "Fleet Card NO" },
                                    //disabled: true,
                                    editorOptions: { width: 150 },
                                },
                                {
                                    dataField: "ERORefNo2",
                                    label: { text: "Plate No" },
                                    editorOptions: { width: 150 },
                                },
                                {
                                    dataField: "ERODate01",
                                    label: { text: "Date" },
                                    editorType: "dxDateBox",
                                    editorOptions: { displayFormat: "dd/MM/yyyy", width: 150 },
                                },
                                {
                                    dataField: "LocalAmount",
                                    label: { text: "Amount" },
                                    editorType: "dxNumberBox",
                                    //format:{ type:"fixedPoint", precision: 2 },
                                    //format: "#,##0.00",
                                    editorOptions: { format: "#,##0.00", rtlEnabled: true, width: 150 },
                                },
                                {
                                    dataField: "EROCheck01",
                                    label: { text: "Pay Slip" },
                                },
                                {
                                    dataField: "EROCheck02",
                                    label: { text: "Tax Invoice" },
                                },
                            ]

                        },
                        {
                            itemType: "group",
                            //caption: "Details",
                            colCount: 2,
                            items: [
                                {
                                    dataField: "ERODesc01",
                                    label: { text: "Note" },
                                    editorType: "dxTextArea",
                                    editorOptions: { width: 800, height: 100 },

                                },
                                // {
                                //      itemType: "button",
                                //      buttonOptions: {
                                //          icon: "save",
                                //          text: "SAVE",
                                //          useSubmitBehavior: true
                                //      }
                                //  }
                            ]
                        }

                        ]

                    }).dxForm("instance");

                    $("#aformSave").on("submit", function (e) {
                        console.log("Done")
                        alert(e)
                        setTimeout(function () {
                            alert("Submitted");
                            alert(e)
                        }, 1000);

                        e.preventDefault();
                    });

                    /*$("#username").dxTextBox({
                            mode: "text",
                            placeholder: "Enter username",
                            showClearButton: true,
                            onValueChanged: function (e) {
                                const previousValue = e.previousValue;
                                ausrs = e.value;
                                // Event handling commands go here
                                // DevExpress.ui.notify(newValue);
                            },
                            width: "250px",
                            value: ""
                    }).dxTextBox("instance");
                            
                    $("#password").dxTextBox({
                            mode: "password",
                            placeholder: "Enter password",
                            showClearButton: true,
                            onValueChanged: function (e) {
                                const previousValue = e.previousValue;
                                apwds = e.value;
                                // Event handling commands go here
                                // DevExpress.ui.notify(newValue);
                            },
                            width: "250px",
                            value: ""
                    }).dxTextBox("instance");
                
                    $("#OTP").dxTextBox({
                            mode: "text",
                            placeholder: "put OTP and press LOGIN",
                            showClearButton: true,
                            onValueChanged: function (e) {
                                const previousValue = e.previousValue;
                                aOTP = e.value;
                                // Event handling commands go here
                                // DevExpress.ui.notify(newValue);
                            },
                            width: "250px",
                            value: ""
                    }).dxTextBox("instance");
                
                    $("#popover1").dxPopover({
                        target: "#OTP",
                        showEvent: "mouseenter",
                        hideEvent: "mouseleave",
                        position: "top",
                        width: 300
                    });*/


                    $("#icon-dones").dxButton({
                        icon: "fas fa-key",
                        type: "success",
                        text: "LOGIN",
                        width: "120px",
                        visible: true,
                        onClick: function (e) {
                            //console.clear();	
                            //var aUname = document.getElementById("uname").value;
                            //var aPswd = document.getElementById("pswd").value; 			
                            if (jQuery.type(ausrs) === "undefined") {
                                var aUname = ""
                            } else {
                                var aUname = ausrs
                            };
                            if (jQuery.type(apwds) === "undefined") {
                                var aPswd = ""
                            } else {
                                var aPswd = apwds;
                            };
                            if (aUname === "" || aPswd === "") {
                                DevExpress.ui.dialog.alert({
                                    showTitle: false,
                                    messageHtml: "<center style='color:Red;'>Username and Password can not be blank !!</center>"
                                });
                            }
                            else {
                                localStorage.setItem("aaPFDMI", aaPFDMI);
                                localStorage.setItem("aaXXuX", aUname);
                                var aaXTGO = "A75FCC75-8FB6-4460-B3F6-7070B4437930"; //Guest
                                var aaTBXX = "01f518c9-c818-4e9f-85cb-6245ee1a2637";
                                //var aaLng = aaLoginGet(aaPFDMI,aUname, aPswd); //aaLoginaa(aUname,aPswd);
                                //alert(aUname);
                                var aLtext = "IDUsr='" + aUname + "' and Pword='" + aPswd + "'"
                                //alert(aLtext);
                                //"@": "IDUsr='" + aUname + "' and Pword='" + aPswd + "'"
                                var myHeaders = new Headers();
                                myHeaders.append("Content-Type", "application/json");
                                var raw = JSON.stringify({
                                    "@": "IDUsr='" + aUname + "' and Pword='" + aPswd + "'"
                                });

                                var requestOptions = {
                                    method: 'POST',
                                    headers: myHeaders,
                                    body: raw,
                                    redirect: 'follow'
                                };

                                let aURL = aaPFDMI + "/DMQ/XOL/" + aaXTGO + "/" + aaTBXX + "/all"; // + aUname;

                                fetch(aURL, requestOptions)
                                    .then(response => response.json())
                                    //  .then(data => {console.log(data)});
                                    .then(aData => {
                                        //console.log('Success:', aData);
                                        //console.log(aData[0].IDUsr);
                                        //console.log(aData[0].Gright);
                                        //console.log(aData[0].Pword);
                                        //console.log(result);
                                        //localStorage.setItem("aaXXoX", aData[0].TKey); 
                                        //localStorage.setItem("aaXrXg", response.KeyRights);                        
                                        if (aPswd === aData[0].Pword) {
                                            var aal = btoa(aData[0].Gright);
                                            var aat = btoa(aData[0].Tkey);
                                            var aLGName = aData[0].LGName;
                                            var aemail = aData[0].email;
                                            var aotpx = aData[0].otp;
                                            var apict = aData[0].PictureLoc;
                                            //console.log(aLGName)
                                            //console.log(aemail)
                                            //console.log(aotpx)
                                            //alert(aal);
                                            //alert(aData[0].Pword);
                                            //alert(aPswd === aData[0].Pword);
                                            localStorage.setItem("aaXrXg", aal);
                                            localStorage.setItem("aaXXoX", aat);
                                            localStorage.setItem("aaXpXt", apict);

                                            if (aOTP === aOTPm || aWOTP === 0) {
                                                //aGoTo("index02.html");
                                                aGoTo("index03.html");
                                            } else {
                                                aii++;
                                                $("#username").hide();
                                                $("#password").hide();
                                                $("#OTP").show(20);
                                                if (aii <= 1) {
                                                    var aP1Body = '<table style="height: 40px;" border="0" width="200" cellspacing="0" cellpadding="0"><tbody><tr style="height: 40px;"><td style="width: 200px; text-align: left; height: 40px;" align="center" bgcolor="#483D8B"><h2><span style="color: #ffffff;"><center><strong>OTP =&nbsp;' + aOTPm + '</center></strong></span></h2></td></tr></tbody></table>'
                                                    // 
                                                    //                                       aRecipient, aRCPeMail               ,aSendereMail        , aCCeMail, aBcceMail,aSubject,aMessage "Dear Wikran <br/><br/>&nbsp;&nbsp; OTP = <br/><br/><br/>Regards,<br />XOL Admin."
                                                    var lSentM = aSendMailDMZ("Khun " + aLGName, aemail, "XOL-admin@lockton.com", "wikran@hotmail.com", "", "OTP = " + aOTPm, "<div style='font-family:tahoma; font-size:12px;' > Dear Khun " + aLGName + ", <br/><br/>" + aP1Body + "<br/><br/>Regards,<br/>XOL Admin.<br/><br/><i>(Plese do not reply this mail !!)<i></div>");

                                                    DevExpress.ui.dialog.alert({
                                                        showTitle: false,
                                                        messageHtml: "<center style='color:ForestGreen;'> Sendind OTP to your e-Mail, please check </center>"
                                                    });
                                                } else {
                                                    DevExpress.ui.dialog.alert({
                                                        showTitle: false,
                                                        messageHtml: "<center style='color:Red;'> Please check OTP from your e-Mail again !!" + aii + "</center>"
                                                    });
                                                }
                                            }

                                        } else {

                                            DevExpress.ui.dialog.alert({
                                                showTitle: false,
                                                messageHtml: "<center><b style='color:Tomato;'>Please Try Again!!</b></center>"
                                            });
                                        }

                                    })
                                    .catch(error => {
                                        console.error('Error:', error);
                                        DevExpress.ui.dialog.alert({
                                            showTitle: false,
                                            messageHtml: "<center><b style='color:Tomato;'>Please Try Again!!</b></center>"
                                        });
                                    });

                            }
                        }
                    });

                });
            }

            function aPivotPopUp() { //, aaHeadRefNo, taData
                console.log(aaDeptList, "inside Pivot")
                //var aqrIDNo = "IDNO = '" + iData.IDNO + "'"
                //var aqrStatus = "Status = 'Lapse'"
                //var aaRWIDNOa = iData.IDNO
                //var aaRWSfIDa = iData.STAFFID
                //var aaRWSfNmea = iData.STAFFNAME.substring(0, 20)
                //var aaRWDNNoa = iData.InvRefNo
                //var aaRWStatusa = iData.Status
                //var aaDbNmea = "SIBISDB"
                //var aTableNamea = "RWFollowUp"
                //var aaiHeadRef = aaHeadRefNo;
                //var aaSchRef = "HeadRefNo LIKE '%" + aaHeadRefNo + "%'" // scopes based permission (View Only Login Name)
                let drillDownDataSource = {};
                // define the $ as jQuery for multiple uses
                jQuery(function ($) {
                    // ...
                    //var gbxRateV = 1;
                    const popup = $("#PivotPopUp").dxPopup({
                        title: "Expenses Reimbursement Pivot",
                        width: '1300px',
                        position: { offset: "0 -140" }, //{offset: "0 -180"},
                        //position: {offset: "40 -200"}, //{my:"top", at:"top", of:window},
                        visible: true,
                        fullScreen: true,
                        showCloseButton: false,
                        showTitle: true,
                        dragEnabled: true,
                        closeOnOutsideClick: false,
                        resizeEnabled: true,
                        //shadingColor:"rgb(190,190,190,0.9)",
                        //toolbarItems: [{toolbar:"top", html: "<span id='popupexit'></span>"}],
                        //toolbarItems: [
                        //    {toolbar:"top", html:"<div padding-top: -7px;><center><img src='./images/locktonlogo70mmblack.png' width='88'></center></div>"}],            
                        contentTemplate: function () {
                            return $("<div />").append(
                                $("<p><div id='aAgentPivot'></div></p>"), //acStatus
                                $("<div id='popupexit' style='margin:5px;'></div></p>"),
                                //$("<p><div id='Status-dxDataGrid'></div></p>"),
                                //$("<p><div id='aSchxx' style='margin:5px;'></div>"), //acStatus
                                //$("<div id='asave' style='margin:5px;'></div>"),
                                //$("<p><div id='account-chart' style='padding-top: -10px; font-size: 9pt;'></div></p>"),
                                //$("<p><div id='fu-datagrida'></div></p>"),                              
                            );
                        },
                        toolbarItems: [
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                //html: "<div padding-top: -7px;><img src='./images/locktonlogo70mmblack.png' width='85'></div>"
                            },
                            /*
                             {
                                 toolbar: "top",
                                 locateInMenu: 'always',
                                 widget: "dxButton",
                                 //toolbar: "bottom",
                                 location: "right",
                                 options: {
                                     icon: "print",
                                     //text: "Print",
                                     onClick: function () {
                                         window.print()
                                     }
                                 }
                             },*/
                            {
                                toolbar: "top",
                                locateInMenu: 'always',
                                widget: "dxButton",
                                //toolbar: "bottom",
                                location: "after",
                                options: {
                                    //text: "EXIT",
                                    icon: "fas fa-times",
                                    //type: "danger",                
                                    onClick: function (e) {
                                        popup.hide();
                                    }
                                }
                            }]

                    }).dxPopup("instance");


                    $("#popupexit").dxButton({
                        icon: "fas fa-times",
                        type: "danger",
                        stylingMode: "outlined",
                        text: "EXIT",
                        width: "120px",
                        visible: true,
                        onClick: function () {
                            //Check if Local Amount = 0 then delete Records
                            $("#gridContainer").dxDataGrid("instance").refresh();
                            //$("#gridContainer").dxDataGrid("instance").refresh();
                            popup.hide();
                        }
                    });

                    $("#print").dxButton({
                        icon: "print",
                        //text: "Print",
                        onClick: function () {
                            window.print();
                        }
                    });


                    $('#aAgentPivot').dxPivotGrid({
                        allowSorting: true,
                        allowFiltering: true,
                        allowSortingBySummary: true,
                        allowExpandAll: true,
                        height: 620,
                        showBorders: true,
                        fieldChooser: {
                            allowSearch: true,
                        },
                        fieldPanel: {
                            visible: true,
                            showFilterFields: true,
                        },
                        //rowHeaderLayout: 'tree',
                        headerFilter: {
                            allowSearch: true,
                        },
                        scrolling: {
                            mode: 'virtual',
                        },
                        export: {
                            enabled: true,
                        },
                        onCellClick(e) {
                            if (e.area === 'data') {
                                const pivotGridDataSource = e.component.getDataSource();
                                const rowPathLength = e.cell.rowPath.length;
                                const rowPathName = e.cell.rowPath[rowPathLength - 1];
                                const popupTitle = `${rowPathName || 'Total'} Drill Down Data`;

                                drillDownDataSource = pivotGridDataSource.createDrillDownDataSource(e.cell);
                                salesPopup.option('title', popupTitle);
                                salesPopup.show();
                            }
                        },
                        dataSource: {
                            //remoteOperations: true,
                            //store: iData,
                            store: new DevExpress.data.CustomStore({
                                key: "IDNO",
                                loadMode: "raw", //raw omit  "xmla"
                                load: function () { return $.post(aSettings).done(); },
                            }),
                            //"HeadRefNo,ReqDate,PayToCode,PayToName,Department,Division,ExpGroupCode,ExpGroupDescEng,Confirmed,ConfirmedDate,HODApproved,HODApprovedDate,HRApproved,HRApprovedDate,Approved,FAApprovedDate,PBatchNo,PBatchDate,PSPvNO,PSPvDate,Currency,Xrate,TotalAmount,TotalLocalAmount,TotalReimburse,ERStatus,ReqEmail,APPEmail,APPName,LimitAmount,LimitPerTime,MaternityLimit,nRecord
                            fields: [
                                {
                                    caption: 'Name',
                                    dataField: 'PayToName',
                                    width: 200,
                                    dataType: "string",
                                    expanded: true,
                                    sortBySummaryField: 'NO OF ITEM',
                                    //sortBySummaryPath: [],
                                    //sortOrder: 'desc',
                                    area: 'row',
                                },
                                {
                                    dataField: "Department",
                                    caption: "Department Name",
                                    dataType: "string",
                                },
                                {
                                    caption: 'Req. Date',
                                    dataField: 'ReqDate',
                                    dataType: 'date',
                                    width: 120,
                                    expanded: true,
                                    //summaryType: 'count',
                                    //format: "MM/yyyy",
                                    //sortBySummaryField: 'NO OF ITEM',
                                    //sortBySummaryPath: [],
                                    //sortOrder: 'desc',
                                    //area: 'column',
                                },
                                {
                                    groupName: 'ReqDate',
                                    groupInterval: 'year', //['ReqDate', '>=', aFilterT], "and", ['ReqDate', '<=', aFilterT2]
                                    //area: 'filter', // filtering
                                }, {
                                    groupName: 'ReqDate',
                                    groupInterval: 'quarter',
                                    //area: 'filter', // filtering
                                },
                                {
                                    dataField: "ExpGroupDescEng",//"ExpensesDescription",
                                    caption: "Expenses",
                                    dataType: "string",
                                    width: 200,
                                    expanded: true,
                                    //filterValues: [null,""],
                                    //filterType: "exclude", 
                                    filterValues: ["Medical","Fleet Card"], // Filter by date range
                                    filterType: "include",
                                    area: 'column'
                                },
                                {
                                    dataField: "ERORefNo3",//"ExpensesDescription",
                                    caption: "Sub Expenses",
                                    dataType: "string",
                                    width: 150,
                                    visible: false,
                                    //area: 'row'
                                },
                                {
                                    dataField: "ReqDate",
                                    caption: "Requested Date",
                                    dataType: "date",
                                    area: 'fliter', //'filter', // Placing the status field in the filter area
                                    // Apply filter condition here:
                                    filterValues: [[aFilterT, aFilterT2]], // Filter by date range
                                    filterType: "include",
                                    filter: function (date) {
                                        // Ensure ReqDate is between aFilterT and aFilterT2
                                        console.log("Filtering date:", date);
                                        console.log("Filter range:", aFilterT, aFilterT2);
                                        return date >= aFilterT && date <= aFilterT2;
                                    }
                                },
                                {
                                    dataField: "ERStatus",
                                    caption: "Status",
                                    dataType: "string",
                                    area: 'filter', // Placing the status field in the filter area
                                    filterValues: ["FA Verified and Approved","HOD Approved wait for FA"], // Only include records with 'FA Approved'
                                    filterType: "include", // Including only the specified values
                                },
                                {
                                    caption: 'NO OF ITEM',
                                    dataField: 'Amount',
                                    dataType: 'number',
                                    summaryType: 'count',
                                    format: "#,##0",
                                    //area: 'data',
                                    width: 80,
                                },
                                {
                                    caption: 'Amount',
                                    dataField: 'Amount',
                                    dataType: 'number',
                                    summaryType: 'sum',
                                    format: "#,##0.00",
                                    area: 'data',
                                    width: 120,
                                    visible: false,
                                },
                                {
                                    caption: 'Refunded Amount',
                                    dataField: 'RefundedAmount',
                                    dataType: 'number',
                                    summaryType: 'sum',
                                    format: "#,##0.00",
                                    area: 'data',
                                    width: 100,
                                },
                            ],
                        },
                        onExporting(e) {
                            const workbook = new ExcelJS.Workbook();
                            const worksheet = workbook.addWorksheet('ERList');

                            worksheet.columns = [
                                { width: 70 }, { width: 20 }, { width: 30 }, { width: 30 }//, { width: 30 }, { width: 30 },
                            ];

                            DevExpress.excelExporter.exportPivotGrid({
                                component: e.component,
                                worksheet,
                                topLeftCell: { row: 4, column: 1 },
                                keepColumnWidths: false,
                            }).then((cellRange) => {
                                // Header
                                const headerRow = worksheet.getRow(2);
                                headerRow.height = 30;

                                const columnFromIndex = worksheet.views[0].xSplit + 1;
                                const columnToIndex = columnFromIndex + 3;
                                worksheet.mergeCells(2, columnFromIndex, 2, columnToIndex);

                                const headerCell = headerRow.getCell(columnFromIndex);
                                headerCell.value = 'Expenses Reimbursement [Department]';
                                headerCell.font = { name: 'Segoe UI Light', size: 22, bold: true };
                                headerCell.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };

                                // Footer
                                const footerRowIndex = cellRange.to.row + 2;
                                const footerCell = worksheet.getRow(footerRowIndex).getCell(cellRange.to.column);
                                footerCell.value = aaPFDMI //'https://cbsdev2.locktonwattana.com/XOL/index.html';
                                footerCell.font = { color: { argb: '000000' }, italic: true }; //B6BDB4 BFBFBF
                                footerCell.alignment = { horizontal: 'right' };
                            }).then(() => {
                                workbook.xlsx.writeBuffer().then((buffer) => {
                                    saveAs(new Blob([buffer], { type: 'application/octet-stream' }), 'ERListPivot.xlsx');
                                });
                            });
                            e.cancel = true;
                        },
                    });

                    const salesPopup = $('#sales-popup').dxPopup({
                        width: 850,
                        height: 600,
                        contentTemplate(contentElement) {
                            $('<div />')
                                .addClass('drill-down')
                                .dxDataGrid({
                                    width: 800,
                                    height: 500,
                                    columns: [
                                        {
                                            dataField: "IDNO",
                                            caption: "IDNO",
                                            //sortOrder: "asc",
                                            editorOptions: { readOnly: true, width: 120 },
                                            width: 120,
                                        },
                                        {
                                            dataField: "EXPDATE",
                                            caption: "Expiry Date",
                                            dataType: "date",
                                            format: "dd/MM/yyyy",
                                            editorType: "dxDateBox",
                                            editorOptions: { displayFormat: "dd/MM/yyyy", readOnly: true, width: 100 },
                                            width: 100
                                        },
                                        {
                                            dataField: "OFFICER",
                                            caption: "A/Exec",
                                            editorOptions: { readOnly: true, width: 80 },
                                            width: 80,
                                        },
                                        {
                                            dataField: "Premium",
                                            caption: "Premium",
                                            dataType: "number",
                                            format: { type: "fixedPoint", precision: 2 },
                                            editorOptions: { format: "#,##0.00", readOnly: true, rtlEnabled: true, width: 150 },
                                            width: 150,
                                        },
                                        {
                                            dataField: "NETINCOME",
                                            caption: "Net Income",
                                            dataType: "number",
                                            format: { type: "fixedPoint", precision: 2 },
                                            editorOptions: { format: "#,##0.00", readOnly: true, rtlEnabled: true, width: 150 },
                                            width: 150,
                                        },

                                    ],
                                })
                                .appendTo(contentElement);
                        },
                        onShowing() {
                            $('.drill-down')
                                .dxDataGrid('instance')
                                .option('dataSource', drillDownDataSource);
                        },
                        onShown() {
                            $('.drill-down')
                                .dxDataGrid('instance')
                                .updateDimensions();
                        },
                    }).dxPopup('instance');

                });
            }

        });
        // TOP PRG
    });  // ajax 